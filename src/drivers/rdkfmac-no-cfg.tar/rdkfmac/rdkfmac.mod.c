#include <linux/build-salt.h>
#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(.gnu.linkonce.this_module) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section(__versions) = {
	{ 0xdd8f8694, "module_layout" },
	{ 0x22b90774, "cdev_del" },
	{ 0x2064fa56, "cdev_init" },
	{ 0xc4f0da12, "ktime_get_with_offset" },
	{ 0x13f855c1, "register_pernet_device" },
	{ 0x8587fce0, "genl_register_family" },
	{ 0xafa1d764, "device_release_driver" },
	{ 0x3fd78f3b, "register_chrdev_region" },
	{ 0xdc21e866, "hrtimer_forward" },
	{ 0xeb16b20c, "genl_unregister_family" },
	{ 0xfa599bb2, "netlink_register_notifier" },
	{ 0xa0c6befa, "hrtimer_cancel" },
	{ 0xb3635b01, "_raw_spin_lock_bh" },
	{ 0x56470118, "__warn_printk" },
	{ 0x837b7b09, "__dynamic_pr_debug" },
	{ 0x22e92418, "device_destroy" },
	{ 0x2bd6f057, "ieee80211_unregister_hw" },
	{ 0xdf54a8f7, "netlink_unregister_notifier" },
	{ 0x409bcb62, "mutex_unlock" },
	{ 0x820af94b, "ieee80211_iterate_active_interfaces_atomic" },
	{ 0x6091b333, "unregister_chrdev_region" },
	{ 0x6f638b55, "__platform_driver_register" },
	{ 0x15ba50a6, "jiffies" },
	{ 0xfbdfc558, "hrtimer_start_range_ns" },
	{ 0x2b2a0562, "device_bind_driver" },
	{ 0x37befc70, "jiffies_to_msecs" },
	{ 0x977f511b, "__mutex_init" },
	{ 0xc5850110, "printk" },
	{ 0xa93df26c, "unregister_pernet_device" },
	{ 0xffb7c514, "ida_free" },
	{ 0x2ab7989d, "mutex_lock" },
	{ 0x7749276a, "device_create" },
	{ 0x30cb0399, "init_net" },
	{ 0xc4952f09, "cdev_add" },
	{ 0xc4f7f37d, "ieee80211_stop_tx_ba_cb_irqsafe" },
	{ 0x49c41a57, "_raw_spin_unlock_bh" },
	{ 0xdecd0b29, "__stack_chk_fail" },
	{ 0xd7ec22fe, "wiphy_new_nm" },
	{ 0x2ea2c95c, "__x86_indirect_thunk_rax" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xd793a347, "ieee80211_register_hw" },
	{ 0x1ee7d3cd, "hrtimer_init" },
	{ 0xb65e5a32, "class_destroy" },
	{ 0xf4713ff4, "ieee80211_free_hw" },
	{ 0x1d395187, "device_unregister" },
	{ 0x9e7dd428, "platform_driver_unregister" },
	{ 0x2871e975, "__class_create" },
	{ 0x613069f8, "ieee80211_start_tx_ba_cb_irqsafe" },
	{ 0xe7a02573, "ida_alloc_range" },
};

MODULE_INFO(depends, "mac80211,cfg80211");


MODULE_INFO(srcversion, "62E894458AECD5325476FB7");
