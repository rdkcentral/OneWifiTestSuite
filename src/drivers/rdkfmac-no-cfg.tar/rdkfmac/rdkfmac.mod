/home/yuriym/Downloads/drivers/rdkfmac/rdkfmac_netdev.o /home/yuriym/Downloads/drivers/rdkfmac/rdkfmac_cdev.o /home/yuriym/Downloads/drivers/rdkfmac/rdkfmac_bus.o /home/yuriym/Downloads/drivers/rdkfmac/rdkfmac_cmd.o

