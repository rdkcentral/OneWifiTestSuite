#include "rdkfmac.h"
#include "rdkfmac_cmd.h"
#include "rdkfmac_cfg80211.h"
#include <net/mac80211.h>
#include <linux/ieee80211.h>
#include <linux/rtnetlink.h>
#include <net/genetlink.h>
#include <net/netns/generic.h>
#include <linux/etherdevice.h>
#include <linux/list.h>
#include "wlan_emu_80211_analyzer.h"

#define RDKFMAC_VIF_MAGIC 0x69537748

static inline void rdkfmac_check_magic(struct ieee80211_vif *vif)
{
    struct rdkfmac_vif_priv *vp = (void *)vif->drv_priv;

    WARN(vp->magic != RDKFMAC_VIF_MAGIC,
         "Invalid VIF (%p) magic %#x, %pM, %d/%d\n",
         vif, vp->magic, vif->addr, vif->type, vif->p2p);
}

static inline void rdkfmac_set_magic(struct ieee80211_vif *vif)
{
    struct rdkfmac_vif_priv *vp = (void *)vif->drv_priv;
    vp->magic = RDKFMAC_VIF_MAGIC;
}

static inline void rdkfmac_clear_magic(struct ieee80211_vif *vif)
{
    struct rdkfmac_vif_priv *vp = (void *)vif->drv_priv;
    vp->magic = 0;
}

#define RDKFMAC_STA_MAGIC 0x6d537749

static inline void rdkfmac_check_sta_magic(struct ieee80211_sta *sta)
{
    struct rdkfmac_sta_priv *sp = (void *)sta->drv_priv;
    WARN_ON(sp->magic != RDKFMAC_STA_MAGIC);
}

static inline void rdkfmac_set_sta_magic(struct ieee80211_sta *sta)
{
    struct rdkfmac_sta_priv *sp = (void *)sta->drv_priv;
    sp->magic = RDKFMAC_STA_MAGIC;
}

static inline void rdkfmac_clear_sta_magic(struct ieee80211_sta *sta)
{
    struct rdkfmac_sta_priv *sp = (void *)sta->drv_priv;
    sp->magic = 0;
}

static void mac80211_rdkfmacm_tx(struct ieee80211_hw *hw,
			      struct ieee80211_tx_control *control,
			      struct sk_buff *skb)
{
}

static int mac80211_rdkfmac_start(struct ieee80211_hw *hw)
{
	wlan_emu_spec_data_t	spec;
	wlan_emu_spec_mac80211_t	*mac80211;
	wlan_emu_mac80211_start_t	*start;

	struct mac80211_rdkfmac_data *data = hw->priv;

	printk("%s\n", __func__);
	data->started = true;

	memset(&spec, 0, sizeof(wlan_emu_spec_data_t));
	spec.type = wlan_emu_wlan_spec_type_mac80211;
	mac80211 = &spec.u.mac80211;
	mac80211->ops = wlan_emu_mac80211_ops_type_start;
	start = &mac80211->u.start;
	
	push_to_char_device(&spec);

	return 0;
}

static void mac80211_rdkfmac_stop(struct ieee80211_hw *hw)
{
	struct mac80211_rdkfmac_data *data = hw->priv;
	data->started = false;
	hrtimer_cancel(&data->beacon_timer);
	printk("%s\n", __func__);
}

static int mac80211_rdkfmac_add_interface(struct ieee80211_hw *hw,
					struct ieee80211_vif *vif)
{
	printk("%s (type=%d mac_addr=%pM)\n", __func__, ieee80211_vif_type_p2p(vif), vif->addr);

	rdkfmac_set_magic(vif);

	vif->cab_queue = 0;
	vif->hw_queue[IEEE80211_AC_VO] = 0;
	vif->hw_queue[IEEE80211_AC_VI] = 1;
	vif->hw_queue[IEEE80211_AC_BE] = 2;
	vif->hw_queue[IEEE80211_AC_BK] = 3;

	return 0;
}

static int mac80211_rdkfmac_change_interface(struct ieee80211_hw *hw,
					   struct ieee80211_vif *vif,
					   enum nl80211_iftype newtype,
					   bool newp2p)
{
	newtype = ieee80211_iftype_p2p(newtype, newp2p);

	printk("%s (old type=%d, new type=%d, mac_addr=%pM)\n", __func__,
	    ieee80211_vif_type_p2p(vif), newtype, vif->addr);

	rdkfmac_check_magic(vif);

	vif->cab_queue = 0;

	return 0;
}

static void mac80211_rdkfmac_remove_interface(
	struct ieee80211_hw *hw, struct ieee80211_vif *vif)
{
	printk("%s (type=%d mac_addr=%pM)\n", __func__, ieee80211_vif_type_p2p(vif), vif->addr);

	rdkfmac_check_magic(vif);
	rdkfmac_clear_magic(vif);
}

static inline u64 mac80211_rdkfmac_get_tsf_raw(void)
{
	return ktime_to_us(ktime_get_real());
}

static __le64 __mac80211_rdkfmac_get_tsf(struct mac80211_rdkfmac_data *data)
{
	u64 now = mac80211_rdkfmac_get_tsf_raw();
	return cpu_to_le64(now + data->tsf_offset);
}

static u64 mac80211_rdkfmac_get_tsf(struct ieee80211_hw *hw,
				  struct ieee80211_vif *vif)
{
	struct mac80211_rdkfmac_data *data = hw->priv;
	return le64_to_cpu(__mac80211_rdkfmac_get_tsf(data));
}

static void mac80211_rdkfmac_set_tsf(struct ieee80211_hw *hw,
		struct ieee80211_vif *vif, u64 tsf)
{
	struct mac80211_rdkfmac_data *data = hw->priv;
	u64 now = mac80211_rdkfmac_get_tsf(hw, vif);
	u32 bcn_int = data->beacon_int;
	u64 delta = abs(tsf - now);

	if (tsf > now) {
		data->tsf_offset += delta;
		data->bcn_delta = do_div(delta, bcn_int);
	} else {
		data->tsf_offset -= delta;
		data->bcn_delta = -(s64)do_div(delta, bcn_int);
	}
}

static const char * const rdkfmac_chanwidths[] = {
	[NL80211_CHAN_WIDTH_20_NOHT] = "noht",
	[NL80211_CHAN_WIDTH_20] = "ht20",
	[NL80211_CHAN_WIDTH_40] = "ht40",
	[NL80211_CHAN_WIDTH_80] = "vht80",
	[NL80211_CHAN_WIDTH_80P80] = "vht80p80",
	[NL80211_CHAN_WIDTH_160] = "vht160",
};

static int mac80211_rdkfmac_config(struct ieee80211_hw *hw, u32 changed)
{
	struct mac80211_rdkfmac_data *data = hw->priv;
	struct ieee80211_conf *conf = &hw->conf;
	static const char *smps_modes[IEEE80211_SMPS_NUM_MODES] = {
		[IEEE80211_SMPS_AUTOMATIC] = "auto",
		[IEEE80211_SMPS_OFF] = "off",
		[IEEE80211_SMPS_STATIC] = "static",
		[IEEE80211_SMPS_DYNAMIC] = "dynamic",
	};
	int idx;
#if 0
	if (conf->chandef.chan)
		printk("%s (freq=%d(%d - %d)/%s idle=%d ps=%d smps=%s)\n", __func__,
			conf->chandef.chan->center_freq,
			conf->chandef.center_freq1,
			conf->chandef.center_freq2,
			rdkfmac_chanwidths[conf->chandef.width],
			!!(conf->flags & IEEE80211_CONF_IDLE),
			!!(conf->flags & IEEE80211_CONF_PS),
			smps_modes[conf->smps_mode]);
	else
		printk("%s (freq=0 idle=%d ps=%d smps=%s)\n", __func__,
			!!(conf->flags & IEEE80211_CONF_IDLE),
			!!(conf->flags & IEEE80211_CONF_PS),
			smps_modes[conf->smps_mode]);
#endif

	data->idle = !!(conf->flags & IEEE80211_CONF_IDLE);

	WARN_ON(conf->chandef.chan && data->use_chanctx);

	mutex_lock(&data->mutex);
	if (data->scanning && conf->chandef.chan) {
		for (idx = 0; idx < ARRAY_SIZE(data->survey_data); idx++) {
			if (data->survey_data[idx].channel == data->channel) {
				data->survey_data[idx].start =
					data->survey_data[idx].next_start;
				data->survey_data[idx].end = jiffies;
				break;
			}
		}

		data->channel = conf->chandef.chan;

		for (idx = 0; idx < ARRAY_SIZE(data->survey_data); idx++) {
			if (data->survey_data[idx].channel &&
			    data->survey_data[idx].channel != data->channel)
				continue;
			data->survey_data[idx].channel = data->channel;
			data->survey_data[idx].next_start = jiffies;
			break;
		}
	} else {
		data->channel = conf->chandef.chan;
	}
	mutex_unlock(&data->mutex);

	if (!data->started || !data->beacon_int)
		hrtimer_cancel(&data->beacon_timer);
	else if (!hrtimer_is_queued(&data->beacon_timer)) {
		u64 tsf = mac80211_rdkfmac_get_tsf(hw, NULL);
		u32 bcn_int = data->beacon_int;
		u64 until_tbtt = bcn_int - do_div(tsf, bcn_int);

		hrtimer_start(&data->beacon_timer,
			      ns_to_ktime(until_tbtt * NSEC_PER_USEC),
			      HRTIMER_MODE_REL_SOFT);
	}

	return 0;
}

static void mac80211_rdkfmac_configure_filter(struct ieee80211_hw *hw,
					    unsigned int changed_flags,
					    unsigned int *total_flags,u64 multicast)
{
	struct mac80211_rdkfmac_data *data = hw->priv;

	//printk("%s\n", __func__);

	data->rx_filter = 0;
	if (*total_flags & FIF_ALLMULTI)
		data->rx_filter |= FIF_ALLMULTI;

	*total_flags = data->rx_filter;
}

static void mac80211_rdkfmac_bcn_en_iter(void *data, u8 *mac,
				       struct ieee80211_vif *vif)
{
	unsigned int *count = data;
	struct rdkfmac_vif_priv *vp = (void *)vif->drv_priv;

	if (vp->bcn_en)
		(*count)++;
}

static void mac80211_rdkfmac_bss_info_changed(struct ieee80211_hw *hw,
					    struct ieee80211_vif *vif,
					    struct ieee80211_bss_conf *info,
					    u32 changed)
{
	struct rdkfmac_vif_priv *vp = (void *)vif->drv_priv;
	struct mac80211_rdkfmac_data *data = hw->priv;

	rdkfmac_check_magic(vif);

	printk("%s(changed=0x%x vif->addr=%pM)\n", __func__, changed, vif->addr);

	if (changed & BSS_CHANGED_BSSID) {
		printk("%s: BSSID changed: %pM\n", __func__, info->bssid);
		memcpy(vp->bssid, info->bssid, ETH_ALEN);
	}

	if (changed & BSS_CHANGED_ASSOC) {
		printk("ASSOC: assoc=%d aid=%d\n", info->assoc, info->aid);
		vp->assoc = info->assoc;
		vp->aid = info->aid;
	}

	if (changed & BSS_CHANGED_BEACON_ENABLED) {
		printk("BCN EN: %d (BI=%u)\n", info->enable_beacon, info->beacon_int);
		vp->bcn_en = info->enable_beacon;
		if (data->started &&
		    !hrtimer_is_queued(&data->beacon_timer) &&
		    info->enable_beacon) {
			u64 tsf, until_tbtt;
			u32 bcn_int;
			data->beacon_int = info->beacon_int * 1024;
			tsf = mac80211_rdkfmac_get_tsf(hw, vif);
			bcn_int = data->beacon_int;
			until_tbtt = bcn_int - do_div(tsf, bcn_int);

			hrtimer_start(&data->beacon_timer,
				      ns_to_ktime(until_tbtt * NSEC_PER_USEC),
				      HRTIMER_MODE_REL_SOFT);
		} else if (!info->enable_beacon) {
			unsigned int count = 0;
			ieee80211_iterate_active_interfaces_atomic(
				data->hw, IEEE80211_IFACE_ITER_NORMAL,
				mac80211_rdkfmac_bcn_en_iter, &count);
			printk("beaconing vifs remaining: %u", count);
			if (count == 0) {
				hrtimer_cancel(&data->beacon_timer);
				data->beacon_int = 0;
			}
		}
	}

	if (changed & BSS_CHANGED_ERP_CTS_PROT) {
		printk("ERP_CTS_PROT: %d\n", info->use_cts_prot);
	}

	if (changed & BSS_CHANGED_ERP_PREAMBLE) {
		printk("ERP_PREAMBLE: %d\n", info->use_short_preamble);
	}

	if (changed & BSS_CHANGED_ERP_SLOT) {
		printk("ERP_SLOT: %d\n", info->use_short_slot);
	}

	if (changed & BSS_CHANGED_HT) {
		printk("HT: op_mode=0x%x\n", info->ht_operation_mode);
	}

	if (changed & BSS_CHANGED_BASIC_RATES) {
		printk("BASIC_RATES: 0x%llx\n", (unsigned long long) info->basic_rates);
	}

	if (changed & BSS_CHANGED_TXPOWER)
		printk("TX Power: %d dBm\n", info->txpower);
}

static int mac80211_rdkfmac_sta_add(struct ieee80211_hw *hw,
				  struct ieee80211_vif *vif,
				  struct ieee80211_sta *sta)
{
	rdkfmac_check_magic(vif);
	rdkfmac_set_sta_magic(sta);

	return 0;
}

static int mac80211_rdkfmac_sta_remove(struct ieee80211_hw *hw,
				     struct ieee80211_vif *vif,
				     struct ieee80211_sta *sta)
{
	rdkfmac_check_magic(vif);
	rdkfmac_clear_sta_magic(sta);

	return 0;
}

static void mac80211_rdkfmac_sta_notify(struct ieee80211_hw *hw,
				      struct ieee80211_vif *vif,
				      enum sta_notify_cmd cmd,
				      struct ieee80211_sta *sta)
{
	rdkfmac_check_magic(vif);
}

static int mac80211_rdkfmac_set_tim(struct ieee80211_hw *hw,
				  struct ieee80211_sta *sta,
				  bool set)
{
	rdkfmac_check_sta_magic(sta);
	return 0;
}

static int mac80211_rdkfmac_conf_tx(
	struct ieee80211_hw *hw,
	struct ieee80211_vif *vif, u16 queue,
	const struct ieee80211_tx_queue_params *params)
{
	printk("%s (queue=%d txop=%d cw_min=%d cw_max=%d aifs=%d)\n",
		__func__, queue,
		params->txop, params->cw_min,
		params->cw_max, params->aifs);
	return 0;
}

static int mac80211_rdkfmac_get_survey(struct ieee80211_hw *hw, int idx,
				     struct survey_info *survey)
{
	struct mac80211_rdkfmac_data *rdkfmac = hw->priv;

	if (idx < 0 || idx >= ARRAY_SIZE(rdkfmac->survey_data))
		return -ENOENT;

	mutex_lock(&rdkfmac->mutex);
	survey->channel = rdkfmac->survey_data[idx].channel;
	if (!survey->channel) {
		mutex_unlock(&rdkfmac->mutex);
		return -ENOENT;
	}

	//XXX hardcode
	survey->filled = SURVEY_INFO_NOISE_DBM |
			 SURVEY_INFO_TIME |
			 SURVEY_INFO_TIME_BUSY;
	survey->noise = -92;
	survey->time =
		jiffies_to_msecs(rdkfmac->survey_data[idx].end - rdkfmac->survey_data[idx].start);
	survey->time_busy = survey->time/7;
	mutex_unlock(&rdkfmac->mutex);

	return 0;
}

static int mac80211_rdkfmac_ampdu_action(struct ieee80211_hw *hw,
				       struct ieee80211_vif *vif,
				       struct ieee80211_ampdu_params *params)
{
	struct ieee80211_sta *sta = params->sta;
	enum ieee80211_ampdu_mlme_action action = params->action;
	u16 tid = params->tid;

	switch (action) {
	case IEEE80211_AMPDU_TX_START:
		ieee80211_start_tx_ba_cb_irqsafe(vif, sta->addr, tid);
		break;
	case IEEE80211_AMPDU_TX_STOP_CONT:
	case IEEE80211_AMPDU_TX_STOP_FLUSH:
	case IEEE80211_AMPDU_TX_STOP_FLUSH_CONT:
		ieee80211_stop_tx_ba_cb_irqsafe(vif, sta->addr, tid);
		break;
	case IEEE80211_AMPDU_TX_OPERATIONAL:
		break;
	case IEEE80211_AMPDU_RX_START:
	case IEEE80211_AMPDU_RX_STOP:
		break;
	default:
		return -EOPNOTSUPP;
	}

	return 0;
}

static void mac80211_rdkfmac_flush(struct ieee80211_hw *hw,
				 struct ieee80211_vif *vif,
				 u32 queues, bool drop)
{
}

static const char mac80211_rdkfmac_gstrings_stats[][ETH_GSTRING_LEN] = {
	"tx_pkts_nic",
	"tx_bytes_nic",
	"rx_pkts_nic",
	"rx_bytes_nic",
	"d_tx_dropped",
	"d_tx_failed",
	"d_ps_mode",
	"d_group",
};

#define MAC80211_RDKFMAC_SSTATS_LEN ARRAY_SIZE(mac80211_rdkfmac_gstrings_stats)

static void mac80211_rdkfmac_get_et_strings(struct ieee80211_hw *hw,
					  struct ieee80211_vif *vif,
					  u32 sset, u8 *data)
{
	if (sset == ETH_SS_STATS) {
		memcpy(data, *mac80211_rdkfmac_gstrings_stats,
		       sizeof(mac80211_rdkfmac_gstrings_stats));
	}
}

static int mac80211_rdkfmac_get_et_sset_count(struct ieee80211_hw *hw,
					    struct ieee80211_vif *vif, int sset)
{
	if (sset == ETH_SS_STATS)
		return MAC80211_RDKFMAC_SSTATS_LEN;
	return 0;
}

static void mac80211_rdkfmac_get_et_stats(struct ieee80211_hw *hw,
					struct ieee80211_vif *vif,
					struct ethtool_stats *stats, u64 *data)
{
	struct mac80211_rdkfmac_data *ar = hw->priv;
	int i = 0;

	data[i++] = ar->tx_pkts;
	data[i++] = ar->tx_bytes;
	data[i++] = ar->rx_pkts;
	data[i++] = ar->rx_bytes;
	data[i++] = ar->tx_dropped;
	data[i++] = ar->tx_failed;
	data[i++] = ar->ps;
	data[i++] = ar->group;

	WARN_ON(i != MAC80211_RDKFMAC_SSTATS_LEN);
}

static void mac80211_rdkfmac_sw_scan(struct ieee80211_hw *hw,
				   struct ieee80211_vif *vif,
				   const u8 *mac_addr)
{
}

static void mac80211_rdkfmac_sw_scan_complete(struct ieee80211_hw *hw,
					    struct ieee80211_vif *vif)
{
}

int mac80211_rdkfmac_start_ap(struct ieee80211_hw *hw, struct ieee80211_vif *vif)
{
	printk("%s:%d\n", __func__, __LINE__);
	return 0;
}

void mac80211_rdkfmac_stop_ap(struct ieee80211_hw *hw, struct ieee80211_vif *vif)
{
	printk("%s:%d\n", __func__, __LINE__);
}

static const struct ieee80211_ops mac80211_rdkfmac_ops = {
	.tx = mac80211_rdkfmacm_tx,				
	.start = mac80211_rdkfmac_start,				
	.stop = mac80211_rdkfmac_stop,				
	.add_interface = mac80211_rdkfmac_add_interface,		
	.change_interface = mac80211_rdkfmac_change_interface,	
	.remove_interface = mac80211_rdkfmac_remove_interface,	
	.config = mac80211_rdkfmac_config,			
	.configure_filter = mac80211_rdkfmac_configure_filter,	
	.bss_info_changed = mac80211_rdkfmac_bss_info_changed,	
	.start_ap = mac80211_rdkfmac_start_ap,
	.stop_ap = mac80211_rdkfmac_stop_ap,
	.sta_add = mac80211_rdkfmac_sta_add,			
	.sta_remove = mac80211_rdkfmac_sta_remove,		
	.sta_notify = mac80211_rdkfmac_sta_notify,		
	.set_tim = mac80211_rdkfmac_set_tim,			
	.conf_tx = mac80211_rdkfmac_conf_tx,			
	.get_survey = mac80211_rdkfmac_get_survey,		
	.ampdu_action = mac80211_rdkfmac_ampdu_action,		
	.flush = mac80211_rdkfmac_flush,				
	.get_tsf = mac80211_rdkfmac_get_tsf,			
	.set_tsf = mac80211_rdkfmac_set_tsf,			
	.get_et_sset_count = mac80211_rdkfmac_get_et_sset_count,	
	.get_et_stats = mac80211_rdkfmac_get_et_stats,		
	.get_et_strings = mac80211_rdkfmac_get_et_strings,
	.sw_scan_start = mac80211_rdkfmac_sw_scan,
	.sw_scan_complete = mac80211_rdkfmac_sw_scan_complete,
};

struct ieee80211_ops *rdkfmac_get_ieee80211_ops()
{
	return &mac80211_rdkfmac_ops;
}
