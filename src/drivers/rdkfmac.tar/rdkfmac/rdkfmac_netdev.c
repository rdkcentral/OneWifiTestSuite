#include "rdkfmac.h"
#include "rdkfmac_cmd.h"
#include "rdkfmac_cfg80211.h"
#include <net/mac80211.h>
#include <linux/ieee80211.h>
#include <linux/rtnetlink.h>
#include <net/genetlink.h>
#include <net/netns/generic.h>
#include <linux/etherdevice.h>
#include <linux/list.h>

const unsigned char rdkfmac_mac_addr[ETH_ALEN] = {0xab, 0xbc, 0xcd, 0xde, 0xef};

struct rdkfmac_ieee80211_driver {
	struct ieee80211_hw hw;

	const struct ieee80211_ops *ops;

	u8 ext_capa[8];
};


static const struct ieee80211_txrx_stypes
rdkfmac_cfg80211_default_mgmt_stypes[NUM_NL80211_IFTYPES] = {
	[NL80211_IFTYPE_STATION] = {
		.tx = 0xffff,
		.rx = BIT(IEEE80211_STYPE_ACTION >> 4) |
		BIT(IEEE80211_STYPE_PROBE_REQ >> 4)
	},
	[NL80211_IFTYPE_AP] = {
		.tx = 0xffff,
		.rx = BIT(IEEE80211_STYPE_ASSOC_REQ >> 4) |
		BIT(IEEE80211_STYPE_REASSOC_REQ >> 4) |
		BIT(IEEE80211_STYPE_PROBE_REQ >> 4) |
		BIT(IEEE80211_STYPE_DISASSOC >> 4) |
		BIT(IEEE80211_STYPE_AUTH >> 4) |
		BIT(IEEE80211_STYPE_DEAUTH >> 4) |
		BIT(IEEE80211_STYPE_ACTION >> 4)
	},
};

static void *rdkfmac_wiphy_privid = &rdkfmac_wiphy_privid;

static struct wireless_dev *rdkfmac_add_virtual_intf(struct wiphy *wiphy,
                          const char *name,
                          unsigned char name_assign_t,
                          enum nl80211_iftype type,
                          struct vif_params *params)
{  
	int ret = 0;

	return ERR_PTR(ret);
}

static int
rdkfmac_change_virtual_intf(struct wiphy *wiphy,
             struct net_device *dev,
             enum nl80211_iftype type,
             struct vif_params *params)
{   
	return 0;
}

int rdkfmac_del_virtual_intf(struct wiphy *wiphy, struct wireless_dev *wdev)
{
	return 0;
}

static int rdkfmac_start_ap(struct wiphy *wiphy, struct net_device *dev,
             struct cfg80211_ap_settings *settings)
{
	return 0;   
}

static int rdkfmac_change_beacon(struct wiphy *wiphy, struct net_device *dev,
                  struct cfg80211_beacon_data *info)
{

    return 0;
}   

static int rdkfmac_stop_ap(struct wiphy *wiphy, struct net_device *dev,
            unsigned int link_id)
{ 
	return 0;
}

static int rdkfmac_set_wiphy_params(struct wiphy *wiphy, u32 changed)
{
	return 0;
}

static void
rdkfmac_update_mgmt_frame_registrations(struct wiphy *wiphy,
                     struct wireless_dev *wdev,
                     struct mgmt_frame_regs *upd)
{  

}

static int
rdkfmac_mgmt_tx(struct wiphy *wiphy, struct wireless_dev *wdev,
         struct cfg80211_mgmt_tx_params *params, u64 *cookie)
{
	return 0;
}

static int
rdkfmac_change_station(struct wiphy *wiphy, struct net_device *dev,
            const u8 *mac, struct station_parameters *params)
{
	return 0;
}

static int
rdkfmac_del_station(struct wiphy *wiphy, struct net_device *dev,
         struct station_del_parameters *params)
{
	return 0;
}

static int
rdkfmac_get_station(struct wiphy *wiphy, struct net_device *dev,
         const u8 *mac, struct station_info *sinfo)
{    
	return 0;
}

static int
rdkfmac_dump_station(struct wiphy *wiphy, struct net_device *dev,
          int idx, u8 *mac, struct station_info *sinfo)
{ 
	return 0;
}

static int rdkfmac_add_key(struct wiphy *wiphy, struct net_device *dev,
            u8 key_index, bool pairwise,
            const u8 *mac_addr, struct key_params *params)
{
	return 0;
}

static int rdkfmac_del_key(struct wiphy *wiphy, struct net_device *dev,
            u8 key_index, bool pairwise,
            const u8 *mac_addr)
{
	return 0;
}

static int rdkfmac_set_default_key(struct wiphy *wiphy, struct net_device *dev,
                u8 key_index, bool unicast,
                bool multicast)
{
	return 0;
}

static int
rdkfmac_set_default_mgmt_key(struct wiphy *wiphy, struct net_device *dev,
              u8 key_index)
{
	return 0;
}

static int
rdkfmac_scan(struct wiphy *wiphy, struct cfg80211_scan_request *request)
{
	return 0;
}

static int
rdkfmac_connect(struct wiphy *wiphy, struct net_device *dev,
         struct cfg80211_connect_params *sme)
{
	return 0;
}

static int
rdkfmac_external_auth(struct wiphy *wiphy, struct net_device *dev,
           struct cfg80211_external_auth_params *auth)
{
	return 0;
}

static int
rdkfmac_disconnect(struct wiphy *wiphy, struct net_device *dev,
        u16 reason_code)
{
	return 0;
}

static int
rdkfmac_dump_survey(struct wiphy *wiphy, struct net_device *dev,
         int idx, struct survey_info *survey)
{
	return 0;
}

static int
rdkfmac_get_channel(struct wiphy *wiphy, struct wireless_dev *wdev,
         unsigned int link_id, struct cfg80211_chan_def *chandef)
{
	return 0;
}

static int rdkfmac_channel_switch(struct wiphy *wiphy, struct net_device *dev,
                   struct cfg80211_csa_settings *params)
{
	return 0;
}

static int rdkfmac_start_radar_detection(struct wiphy *wiphy,
                      struct net_device *ndev,
                      struct cfg80211_chan_def *chandef,
                      u32 cac_time_ms)
{
	return 0;
}

static int rdkfmac_set_mac_acl(struct wiphy *wiphy,
                struct net_device *dev,
                const struct cfg80211_acl_data *params)
{
	return 0;
}

static int rdkfmac_set_power_mgmt(struct wiphy *wiphy, struct net_device *dev,
                   bool enabled, int timeout)
{
	return 0;
}

static int rdkfmac_get_tx_power(struct wiphy *wiphy, struct wireless_dev *wdev,
                 int *dbm)
{
	return 0;
}

static int rdkfmac_set_tx_power(struct wiphy *wiphy, struct wireless_dev *wdev,
                 enum nl80211_tx_power_setting type, int mbm)
{
	return 0;
}

static int rdkfmac_update_owe_info(struct wiphy *wiphy, struct net_device *dev,
                struct cfg80211_update_owe_info *owe_info)
{
	return 0;
}



static struct cfg80211_ops rdkfmac_cfg80211_ops = {
    .add_virtual_intf   = rdkfmac_add_virtual_intf,
    .change_virtual_intf    = rdkfmac_change_virtual_intf,
    .del_virtual_intf   = rdkfmac_del_virtual_intf,
    .start_ap       = rdkfmac_start_ap,
    .change_beacon      = rdkfmac_change_beacon,
    //.stop_ap        = rdkfmac_stop_ap,
    .set_wiphy_params   = rdkfmac_set_wiphy_params,
    //.update_mgmt_frame_registrations =
     //   rdkfmac_update_mgmt_frame_registrations,
    .mgmt_tx        = rdkfmac_mgmt_tx,
    .change_station     = rdkfmac_change_station,
    .del_station        = rdkfmac_del_station,
    .get_station        = rdkfmac_get_station,
    .dump_station       = rdkfmac_dump_station,
    .add_key        = rdkfmac_add_key,
    .del_key        = rdkfmac_del_key,
    .set_default_key    = rdkfmac_set_default_key,
    .set_default_mgmt_key   = rdkfmac_set_default_mgmt_key,
    .scan           = rdkfmac_scan,
    .connect        = rdkfmac_connect,
    .external_auth      = rdkfmac_external_auth,
    .disconnect     = rdkfmac_disconnect,
    .dump_survey        = rdkfmac_dump_survey,
   // .get_channel        = rdkfmac_get_channel, 
    .channel_switch     = rdkfmac_channel_switch,
    .start_radar_detection  = rdkfmac_start_radar_detection,
    .set_mac_acl        = rdkfmac_set_mac_acl, 
    .set_power_mgmt     = rdkfmac_set_power_mgmt, 
    .get_tx_power       = rdkfmac_get_tx_power,
    .set_tx_power       = rdkfmac_set_tx_power,
    .update_owe_info    = rdkfmac_update_owe_info,
#if 0
    .suspend        = rdkfmac_suspend,
    .resume         = rdkfmac_resume,
    .set_wakeup     = rdkfmac_set_wakeup,
#endif           
};













static spinlock_t radio_lock;
static LIST_HEAD(rdkfmac_radios);

static unsigned int rdkfmac_net_id;

static struct genl_family rdkfmac_genl_family;

static struct class *rdkfmac_class;

static DEFINE_IDA(rdkfmac_netgroup_ida);

struct rdkfmac_net {
	int netgroup;
	u32 wmediumd;
};

static const struct ieee80211_sband_iftype_data he_capa_2ghz[] = {
	{
		.types_mask = BIT(NL80211_IFTYPE_STATION) |
			      BIT(NL80211_IFTYPE_AP),
		.he_cap = {
			.has_he = true,
			.he_cap_elem = {
				.mac_cap_info[0] =
					IEEE80211_HE_MAC_CAP0_HTC_HE,
				.mac_cap_info[1] =
					IEEE80211_HE_MAC_CAP1_TF_MAC_PAD_DUR_16US |
					IEEE80211_HE_MAC_CAP1_MULTI_TID_AGG_RX_QOS_8,
				.mac_cap_info[2] =
					IEEE80211_HE_MAC_CAP2_BSR |
					IEEE80211_HE_MAC_CAP2_MU_CASCADING |
					IEEE80211_HE_MAC_CAP2_ACK_EN,
				.mac_cap_info[3] =
					IEEE80211_HE_MAC_CAP3_OMI_CONTROL |
					IEEE80211_HE_MAC_CAP3_MAX_AMPDU_LEN_EXP_EXT_2,
				.mac_cap_info[4] = IEEE80211_HE_MAC_CAP4_AMSDU_IN_AMPDU,
				.phy_cap_info[1] =
					IEEE80211_HE_PHY_CAP1_PREAMBLE_PUNC_RX_MASK |
					IEEE80211_HE_PHY_CAP1_DEVICE_CLASS_A |
					IEEE80211_HE_PHY_CAP1_LDPC_CODING_IN_PAYLOAD |
					IEEE80211_HE_PHY_CAP1_MIDAMBLE_RX_TX_MAX_NSTS,
				.phy_cap_info[2] =
					IEEE80211_HE_PHY_CAP2_NDP_4x_LTF_AND_3_2US |
					IEEE80211_HE_PHY_CAP2_STBC_TX_UNDER_80MHZ |
					IEEE80211_HE_PHY_CAP2_STBC_RX_UNDER_80MHZ |
					IEEE80211_HE_PHY_CAP2_UL_MU_FULL_MU_MIMO |
					IEEE80211_HE_PHY_CAP2_UL_MU_PARTIAL_MU_MIMO,
			},
			.he_mcs_nss_supp = {
				.rx_mcs_80 = cpu_to_le16(0xfffa),
				.tx_mcs_80 = cpu_to_le16(0xfffa),
				.rx_mcs_160 = cpu_to_le16(0xffff),
				.tx_mcs_160 = cpu_to_le16(0xffff),
				.rx_mcs_80p80 = cpu_to_le16(0xffff),
				.tx_mcs_80p80 = cpu_to_le16(0xffff),
			},
		},
	},
};

static const struct ieee80211_sband_iftype_data he_capa_5ghz[] = {
	{
		.types_mask = BIT(NL80211_IFTYPE_STATION) |
			      BIT(NL80211_IFTYPE_AP),
		.he_cap = {
			.has_he = true,
			.he_cap_elem = {
				.mac_cap_info[0] =
					IEEE80211_HE_MAC_CAP0_HTC_HE,
				.mac_cap_info[1] =
					IEEE80211_HE_MAC_CAP1_TF_MAC_PAD_DUR_16US |
					IEEE80211_HE_MAC_CAP1_MULTI_TID_AGG_RX_QOS_8,
				.mac_cap_info[2] =
					IEEE80211_HE_MAC_CAP2_BSR |
					IEEE80211_HE_MAC_CAP2_MU_CASCADING |
					IEEE80211_HE_MAC_CAP2_ACK_EN,
				.mac_cap_info[3] =
					IEEE80211_HE_MAC_CAP3_OMI_CONTROL |
					IEEE80211_HE_MAC_CAP3_MAX_AMPDU_LEN_EXP_EXT_2,
				.mac_cap_info[4] = IEEE80211_HE_MAC_CAP4_AMSDU_IN_AMPDU,
				.phy_cap_info[0] =
					IEEE80211_HE_PHY_CAP0_CHANNEL_WIDTH_SET_40MHZ_80MHZ_IN_5G |
					IEEE80211_HE_PHY_CAP0_CHANNEL_WIDTH_SET_160MHZ_IN_5G |
					IEEE80211_HE_PHY_CAP0_CHANNEL_WIDTH_SET_80PLUS80_MHZ_IN_5G,
				.phy_cap_info[1] =
					IEEE80211_HE_PHY_CAP1_PREAMBLE_PUNC_RX_MASK |
					IEEE80211_HE_PHY_CAP1_DEVICE_CLASS_A |
					IEEE80211_HE_PHY_CAP1_LDPC_CODING_IN_PAYLOAD |
					IEEE80211_HE_PHY_CAP1_MIDAMBLE_RX_TX_MAX_NSTS,
				.phy_cap_info[2] =
					IEEE80211_HE_PHY_CAP2_NDP_4x_LTF_AND_3_2US |
					IEEE80211_HE_PHY_CAP2_STBC_TX_UNDER_80MHZ |
					IEEE80211_HE_PHY_CAP2_STBC_RX_UNDER_80MHZ |
					IEEE80211_HE_PHY_CAP2_UL_MU_FULL_MU_MIMO |
					IEEE80211_HE_PHY_CAP2_UL_MU_PARTIAL_MU_MIMO,

			},
			.he_mcs_nss_supp = {
				.rx_mcs_80 = cpu_to_le16(0xfffa),
				.tx_mcs_80 = cpu_to_le16(0xfffa),
				.rx_mcs_160 = cpu_to_le16(0xfffa),
				.tx_mcs_160 = cpu_to_le16(0xfffa),
				.rx_mcs_80p80 = cpu_to_le16(0xfffa),
				.tx_mcs_80p80 = cpu_to_le16(0xfffa),
			},
		},
	},
};

static inline int rdkfmac_net_get_netgroup(struct net *net)
{
	struct rdkfmac_net *rdkfmac_net = net_generic(net, rdkfmac_net_id);

	return rdkfmac_net->netgroup;
}

static inline int rdkfmac_net_set_netgroup(struct net *net)
{
	struct rdkfmac_net *rdkfmac_net = net_generic(net, rdkfmac_net_id);

	rdkfmac_net->netgroup = ida_simple_get(&rdkfmac_netgroup_ida, 0, 0, GFP_KERNEL);

	return rdkfmac_net->netgroup >= 0 ? 0 : -ENOMEM;
}

static __net_init int rdkfmac_init_net(struct net *net)
{
	return rdkfmac_net_set_netgroup(net);
}

static inline u32 rdkfmac_net_get_wmediumd(struct net *net)
{
	struct rdkfmac_net *rdkfmac_net= net_generic(net, rdkfmac_net_id);

	return rdkfmac_net->wmediumd;
}

static inline void rdkfmac_net_set_wmediumd(struct net *net, u32 portid)
{
	struct rdkfmac_net *rdkfmac_net = net_generic(net, rdkfmac_net_id);

	rdkfmac_net->wmediumd = portid;
}

static void __net_exit rdkfmac_exit_net(struct net *net)
{
	struct mac80211_rdkfmac_data *data, *tmp;

	list_for_each_entry_safe(data, tmp, &rdkfmac_radios, list) {
		list_del(&data->list);
		ieee80211_unregister_hw(data->hw);
		device_release_driver(data->dev);
		device_unregister(data->dev);
		ieee80211_free_hw(data->hw);
	}

	ida_simple_remove(&rdkfmac_netgroup_ida, rdkfmac_net_get_netgroup(net));
}

static struct pernet_operations rdkfmac_net_ops = {
	.init = rdkfmac_init_net,
	.exit = rdkfmac_exit_net,
	.id   = &rdkfmac_net_id,
	.size = sizeof(struct rdkfmac_net),
};

static struct platform_driver mac80211_rdkfmac_driver = {
	.driver = {
		.name = "mac80211_rdkfmac",
	},
};

static void rdkfmac_register_wmediumd(struct net *net, u32 portid)
{
	struct mac80211_rdkfmac_data *data;

	rdkfmac_net_set_wmediumd(net, portid);

	spin_lock_bh(&radio_lock);
	list_for_each_entry(data, &rdkfmac_radios, list) {
		if (data->netgroup == rdkfmac_net_get_netgroup(net))
			data->wmediumd = portid;
	}
	spin_unlock_bh(&radio_lock);
}

static int mac80211_rdkfmac_netlink_notify(struct notifier_block *nb,
					 unsigned long state,
					 void *_notify)
{
	struct netlink_notify *notify = _notify;
	struct mac80211_rdkfmac_data *data, *tmp;
	LIST_HEAD(list);

	if (state != NETLINK_URELEASE)
		return NOTIFY_DONE;

	list_for_each_entry_safe(data, tmp, &list, list) {
	    list_del(&data->list);
	    ieee80211_unregister_hw(data->hw);
	    device_release_driver(data->dev);
	    device_unregister(data->dev);
	    ieee80211_free_hw(data->hw);
	}

	if (notify->portid == rdkfmac_net_get_wmediumd(notify->net)) {
		printk("mac80211_rdkfmac: wmediumd released netlink"
			" socket, switching to perfect channel medium\n");
		rdkfmac_register_wmediumd(notify->net, 0);
	}
	return NOTIFY_DONE;

}

static struct notifier_block rdkfmac_netlink_notifier = {
	.notifier_call = mac80211_rdkfmac_netlink_notify,
};

static int __init rdkfmac_init_netlink(void)
{
	int rc;

	printk("mac80211_rdkfmac: initializing netlink\n");

	rc = genl_register_family(&rdkfmac_genl_family);
	if (rc)
		goto failure;

	rc = netlink_register_notifier(&rdkfmac_netlink_notifier);
	if (rc) {
		genl_unregister_family(&rdkfmac_genl_family);
		goto failure;
	}

	return 0;

failure:
	pr_debug("mac80211_rdkfmac: error occurred in %s\n", __func__);
	return -EINVAL;
}

static void rdkfmac_exit_netlink(void)
{
	netlink_unregister_notifier(&rdkfmac_netlink_notifier);
	genl_unregister_family(&rdkfmac_genl_family);
}

static void mac80211_rdkfmac_free(void)
{
	struct mac80211_rdkfmac_data *data;

	while ((data = list_first_entry_or_null(&rdkfmac_radios,
						struct mac80211_rdkfmac_data,
						list))) {
		list_del(&data->list);
		ieee80211_unregister_hw(data->hw);
		device_release_driver(data->dev);
		device_unregister(data->dev);
		ieee80211_free_hw(data->hw);
	}
	class_destroy(rdkfmac_class);
}

static void mac80211_rdkfmac_he_capab(struct ieee80211_supported_band *sband)
{
	u16 n_iftype_data;

	if (sband->band == NL80211_BAND_2GHZ) {
		n_iftype_data = ARRAY_SIZE(he_capa_2ghz);
		sband->iftype_data =
			(struct ieee80211_sband_iftype_data *)he_capa_2ghz;
	} else if (sband->band == NL80211_BAND_5GHZ) {
		n_iftype_data = ARRAY_SIZE(he_capa_5ghz);
		sband->iftype_data =
			(struct ieee80211_sband_iftype_data *)he_capa_5ghz;
	} else {
		return;
	}

	sband->n_iftype_data = n_iftype_data;
}

static void mac80211_rdkfmac_beacon_tx(void *arg, u8 *mac,
                     struct ieee80211_vif *vif)
{   
}   
    
static enum hrtimer_restart
mac80211_rdkfmac_beacon(struct hrtimer *timer)
{   
    struct mac80211_rdkfmac_data *data =
        container_of(timer, struct mac80211_rdkfmac_data, beacon_timer);
    struct ieee80211_hw *hw = data->hw;
    u64 bcn_int = data->beacon_int;
    
    if (!data->started)
        return HRTIMER_NORESTART;
    
    ieee80211_iterate_active_interfaces_atomic(
        hw, IEEE80211_IFACE_ITER_NORMAL,
        mac80211_rdkfmac_beacon_tx, data);

    if (data->bcn_delta) {
        bcn_int -= data->bcn_delta;
        data->bcn_delta = 0;
    }
    hrtimer_forward(&data->beacon_timer, hrtimer_get_expires(timer),
            ns_to_ktime(bcn_int * NSEC_PER_USEC));
    return HRTIMER_RESTART;
}

static int mac80211_rdkfmac_new_radio(void)
{
	int err;
	u8 addr[ETH_ALEN];
	struct mac80211_rdkfmac_data *data;
	struct ieee80211_hw *hw;
	enum nl80211_band band;
	const struct ieee80211_ops *ops;
	struct net *net;
	int idx, i;
	int n_limits = 0;

	ops = rdkfmac_get_ieee80211_ops();

#ifndef RDKFMAC_FULL
//--------------------------------------------------------------

	struct rdkfmac_ieee80211_driver *local;
	struct wiphy *wiphy;
	int priv_size;

	priv_size = ALIGN(sizeof(*local), NETDEV_ALIGN) + sizeof(*data);

	wiphy = wiphy_new(&rdkfmac_cfg80211_ops, priv_size);

	if (!wiphy)
		return NULL;

	wiphy->mgmt_stypes = rdkfmac_cfg80211_default_mgmt_stypes;
	
	wiphy->privid = rdkfmac_wiphy_privid;

	wiphy->flags |= WIPHY_FLAG_NETNS_OK |
			WIPHY_FLAG_4ADDR_AP |
			WIPHY_FLAG_4ADDR_STATION |
			WIPHY_FLAG_REPORTS_OBSS |
			WIPHY_FLAG_OFFCHAN_TX;

	if (ops->remain_on_channel)
		wiphy->flags |= WIPHY_FLAG_HAS_REMAIN_ON_CHANNEL;

	wiphy->features |= NL80211_FEATURE_SK_TX_STATUS |
			   NL80211_FEATURE_SAE |
			   NL80211_FEATURE_HT_IBSS |
			   NL80211_FEATURE_VIF_TXPOWER |
			   NL80211_FEATURE_MAC_ON_CREATE |
			   NL80211_FEATURE_USERSPACE_MPM |
			   NL80211_FEATURE_FULL_AP_CLIENT_STATE;
	wiphy_ext_feature_set(wiphy, NL80211_EXT_FEATURE_FILS_STA);
	wiphy_ext_feature_set(wiphy,
			      NL80211_EXT_FEATURE_CONTROL_PORT_OVER_NL80211);

	if (!ops->hw_scan) {
		wiphy->features |= NL80211_FEATURE_LOW_PRIORITY_SCAN |
				   NL80211_FEATURE_AP_SCAN;
		/*
		 * if the driver behaves correctly using the probe request
		 * (template) from mac80211, then both of these should be
		 * supported even with hw scan - but let drivers opt in.
		 */
		wiphy_ext_feature_set(wiphy,
				      NL80211_EXT_FEATURE_SCAN_RANDOM_SN);
		wiphy_ext_feature_set(wiphy,
				      NL80211_EXT_FEATURE_SCAN_MIN_PREQ_CONTENT);
	}

	if (!ops->set_key)
		wiphy->flags |= WIPHY_FLAG_IBSS_RSN;

	if (ops->wake_tx_queue)
		wiphy_ext_feature_set(wiphy, NL80211_EXT_FEATURE_TXQS);

	wiphy_ext_feature_set(wiphy, NL80211_EXT_FEATURE_RRM);

	//wiphy->bss_priv_size = sizeof(struct ieee80211_bss);

	local = wiphy_priv(wiphy);

	local->hw.wiphy = wiphy;

	local->hw.priv = (char *)local + ALIGN(sizeof(*local), NETDEV_ALIGN);

	local->ops = ops;

	local->hw.tx_sk_pacing_shift = 7;

	/* set up some defaults */
	local->hw.queues = 1;
	local->hw.max_rates = 1;
	local->hw.max_report_rates = 0;
	local->hw.max_rx_aggregation_subframes = IEEE80211_MAX_AMPDU_BUF_HT;
	local->hw.max_tx_aggregation_subframes = IEEE80211_MAX_AMPDU_BUF_HT;
	local->hw.offchannel_tx_hw_queue = IEEE80211_INVAL_HW_QUEUE;
	local->hw.conf.long_frame_max_tx_count = wiphy->retry_long;
	local->hw.conf.short_frame_max_tx_count = wiphy->retry_short;
	local->hw.radiotap_mcs_details = IEEE80211_RADIOTAP_MCS_HAVE_MCS |
					 IEEE80211_RADIOTAP_MCS_HAVE_GI |
					 IEEE80211_RADIOTAP_MCS_HAVE_BW;
	local->hw.radiotap_vht_details = IEEE80211_RADIOTAP_VHT_KNOWN_GI |
					 IEEE80211_RADIOTAP_VHT_KNOWN_BANDWIDTH;
	local->hw.uapsd_queues = 0;
	local->hw.uapsd_max_sp_len = 0;
	local->hw.max_mtu = IEEE80211_MAX_DATA_LEN;
	//wiphy->ht_capa_mod_mask = &mac80211_ht_capa_mod_mask;
	//wiphy->vht_capa_mod_mask = &mac80211_vht_capa_mod_mask;

	local->ext_capa[7] = WLAN_EXT_CAPA8_OPMODE_NOTIF;

	wiphy->extended_capabilities = local->ext_capa;
	wiphy->extended_capabilities_mask = local->ext_capa;
	wiphy->extended_capabilities_len =
		ARRAY_SIZE(local->ext_capa);

//----------------------------------------




#else
	hw = &local->hw;//ieee80211_alloc_hw_nm(sizeof(*data), ops, "rdkfmac");
#endif
	idx = 0;

	hw = ieee80211_alloc_hw_nm(sizeof(*data), ops, "rdkfmac");
	if (!hw) {
		pr_debug("mac80211_rdkfmac: ieee80211_alloc_hw failed\n");
		err = -ENOMEM;
		goto failed;
	}

	net = &init_net;
	wiphy_net_set(hw->wiphy, net);

	data = hw->priv;
	data->hw = hw;

	data->dev = device_create(rdkfmac_class, NULL, 0, hw, "rdkfmac%d", idx);
	if (IS_ERR(data->dev)) {
		printk("mac80211_rdkfmac: device_create failed (%ld)\n", PTR_ERR(data->dev));
		err = -ENOMEM;
		goto failed_drvdata;
	}
	data->dev->driver = &mac80211_rdkfmac_driver.driver;
	err = device_bind_driver(data->dev);
	if (err != 0) {
		pr_debug("mac80211_rdkfmac: device_bind_driver failed (%d)\n", err);
		goto failed_bind;
	}

	SET_IEEE80211_DEV(hw, data->dev);
	eth_zero_addr(addr);
	memcpy(addr, rdkfmac_mac_addr, ETH_ALEN);
	addr[0] = 0x02;
	addr[3] = idx >> 8;
	addr[4] = idx;
	memcpy(data->addresses[0].addr, addr, ETH_ALEN);
	memcpy(data->addresses[1].addr, addr, ETH_ALEN);
	data->addresses[1].addr[0] |= 0x40;
	hw->wiphy->n_addresses = 2;
	hw->wiphy->addresses = data->addresses;

	data->channels = 1;
	data->use_chanctx = 0;
	data->idx = 0;


	data->if_limits[n_limits].max = 8;

	data->if_limits[n_limits].types = BIT(NL80211_IFTYPE_STATION) | BIT(NL80211_IFTYPE_AP);
	n_limits++;


	data->if_combination.num_different_channels = 1;
	data->if_combination.radar_detect_widths =
	    BIT(NL80211_CHAN_WIDTH_20_NOHT) |
	    BIT(NL80211_CHAN_WIDTH_20) |
	    BIT(NL80211_CHAN_WIDTH_40) |
	    BIT(NL80211_CHAN_WIDTH_80) |
	    BIT(NL80211_CHAN_WIDTH_160);

	if (!n_limits) {
		err = -EINVAL;
		goto failed_hw;
	}

	data->if_combination.max_interfaces = 0;
	for (i = 0; i < n_limits; i++)
		data->if_combination.max_interfaces +=
			data->if_limits[i].max;

	data->if_combination.n_limits = n_limits;
	data->if_combination.limits = data->if_limits;

	if (data->if_combination.max_interfaces > 1) {
		hw->wiphy->iface_combinations = &data->if_combination;
		hw->wiphy->n_iface_combinations = 1;
	}

	hw->queues = 5;
	hw->offchannel_tx_hw_queue = 4;

	ieee80211_hw_set(hw, SUPPORT_FAST_XMIT);
	ieee80211_hw_set(hw, CHANCTX_STA_CSA);
	ieee80211_hw_set(hw, SUPPORTS_HT_CCK_RATES);
	ieee80211_hw_set(hw, QUEUE_CONTROL);
	ieee80211_hw_set(hw, WANT_MONITOR_VIF);
	ieee80211_hw_set(hw, AMPDU_AGGREGATION);
	ieee80211_hw_set(hw, MFP_CAPABLE);
	ieee80211_hw_set(hw, SIGNAL_DBM);
	ieee80211_hw_set(hw, SUPPORTS_PS);
	ieee80211_hw_set(hw, TDLS_WIDER_BW);
	ieee80211_hw_set(hw, SUPPORTS_MULTI_BSSID);

	hw->wiphy->flags |= WIPHY_FLAG_SUPPORTS_TDLS |
			    WIPHY_FLAG_HAS_REMAIN_ON_CHANNEL |
			    WIPHY_FLAG_AP_UAPSD |
			    WIPHY_FLAG_HAS_CHANNEL_SWITCH;
	hw->wiphy->features |= NL80211_FEATURE_ACTIVE_MONITOR |
			       NL80211_FEATURE_AP_MODE_CHAN_WIDTH_CHANGE |
			       NL80211_FEATURE_STATIC_SMPS |
			       NL80211_FEATURE_DYNAMIC_SMPS |
			       NL80211_FEATURE_SCAN_RANDOM_MAC_ADDR;
	wiphy_ext_feature_set(hw->wiphy, NL80211_EXT_FEATURE_VHT_IBSS);

	hw->wiphy->interface_modes = BIT(NL80211_IFTYPE_STATION) | BIT(NL80211_IFTYPE_AP);

	hw->vif_data_size = sizeof(struct rdkfmac_vif_priv);
	hw->sta_data_size = sizeof(struct rdkfmac_sta_priv);

	memcpy(data->channels_2ghz, rdkfmac_channels_2ghz, sizeof(rdkfmac_channels_2ghz));
	memcpy(data->channels_5ghz, rdkfmac_channels_5ghz, sizeof(rdkfmac_channels_5ghz));
	memcpy(data->rates, rdkfmac_rates, sizeof(rdkfmac_rates));

	for (band = NL80211_BAND_2GHZ; band < NUM_NL80211_BANDS; band++) {
		struct ieee80211_supported_band *sband = &data->bands[band];

		sband->band = band;

		switch (band) {
		case NL80211_BAND_2GHZ:
			sband->channels = data->channels_2ghz;
			sband->n_channels = ARRAY_SIZE(rdkfmac_channels_2ghz);
			sband->bitrates = data->rates;
			sband->n_bitrates = ARRAY_SIZE(rdkfmac_rates);
			break;
		case NL80211_BAND_5GHZ:
			sband->channels = data->channels_5ghz;
			sband->n_channels = ARRAY_SIZE(rdkfmac_channels_5ghz);
			sband->bitrates = data->rates + 4;
			sband->n_bitrates = ARRAY_SIZE(rdkfmac_rates) - 4;

			sband->vht_cap.vht_supported = true;
			sband->vht_cap.cap =
				IEEE80211_VHT_CAP_MAX_MPDU_LENGTH_11454 |
				IEEE80211_VHT_CAP_SUPP_CHAN_WIDTH_160_80PLUS80MHZ |
				IEEE80211_VHT_CAP_RXLDPC |
				IEEE80211_VHT_CAP_SHORT_GI_80 |
				IEEE80211_VHT_CAP_SHORT_GI_160 |
				IEEE80211_VHT_CAP_TXSTBC |
				IEEE80211_VHT_CAP_RXSTBC_4 |
				IEEE80211_VHT_CAP_MAX_A_MPDU_LENGTH_EXPONENT_MASK;
			sband->vht_cap.vht_mcs.rx_mcs_map =
				cpu_to_le16(IEEE80211_VHT_MCS_SUPPORT_0_9 << 0 |
					    IEEE80211_VHT_MCS_SUPPORT_0_9 << 2 |
					    IEEE80211_VHT_MCS_SUPPORT_0_9 << 4 |
					    IEEE80211_VHT_MCS_SUPPORT_0_9 << 6 |
					    IEEE80211_VHT_MCS_SUPPORT_0_9 << 8 |
					    IEEE80211_VHT_MCS_SUPPORT_0_9 << 10 |
					    IEEE80211_VHT_MCS_SUPPORT_0_9 << 12 |
					    IEEE80211_VHT_MCS_SUPPORT_0_9 << 14);
			sband->vht_cap.vht_mcs.tx_mcs_map =
				sband->vht_cap.vht_mcs.rx_mcs_map;
			break;
		default:
			continue;
		}

		sband->ht_cap.ht_supported = true;
		sband->ht_cap.cap = IEEE80211_HT_CAP_SUP_WIDTH_20_40 |
				    IEEE80211_HT_CAP_GRN_FLD |
				    IEEE80211_HT_CAP_SGI_20 |
				    IEEE80211_HT_CAP_SGI_40 |
				    IEEE80211_HT_CAP_DSSSCCK40;
		sband->ht_cap.ampdu_factor = 0x3;
		sband->ht_cap.ampdu_density = 0x6;
		memset(&sband->ht_cap.mcs, 0,
		       sizeof(sband->ht_cap.mcs));
		sband->ht_cap.mcs.rx_mask[0] = 0xff;
		sband->ht_cap.mcs.rx_mask[1] = 0xff;
		sband->ht_cap.mcs.tx_params = IEEE80211_HT_MCS_TX_DEFINED;

		mac80211_rdkfmac_he_capab(sband);

		hw->wiphy->bands[band] = sband;
	}

	data->group = 1;
	mutex_init(&data->mutex);

	data->netgroup = rdkfmac_net_get_netgroup(net);
	data->wmediumd = rdkfmac_net_get_wmediumd(net);

	/* Enable frame retransmissions for lossy channels */
	hw->max_rates = 4;
	hw->max_rate_tries = 11;

	wiphy_ext_feature_set(hw->wiphy, NL80211_EXT_FEATURE_CQM_RSSI_LIST);

	hrtimer_init(&data->beacon_timer, CLOCK_MONOTONIC,
		     HRTIMER_MODE_ABS_SOFT);
	data->beacon_timer.function = mac80211_rdkfmac_beacon;

	err = ieee80211_register_hw(hw);
	if (err < 0) {
		pr_debug("mac80211_rdkfmac: ieee80211_register_hw failed (%d)\n", err);
		goto failed_hw;
	}

	printk("hwaddr %pM registered\n", hw->wiphy->perm_addr);

	spin_lock_bh(&radio_lock);
	list_add_tail(&data->list, &rdkfmac_radios);
	spin_unlock_bh(&radio_lock);

	return 0;

failed_hw:
	device_release_driver(data->dev);
failed_bind:
	device_unregister(data->dev);
failed_drvdata:
	ieee80211_free_hw(hw);
failed:
	return err;
}

static netdev_tx_t hwsim_mon_xmit(struct sk_buff *skb,
					struct net_device *dev)
{
	/* TODO: allow packet injection */
	dev_kfree_skb(skb);
	return NETDEV_TX_OK;
}

static const struct net_device_ops hwsim_netdev_ops = {
	.ndo_start_xmit 	= hwsim_mon_xmit,
	.ndo_set_mac_address 	= eth_mac_addr,
	.ndo_validate_addr	= eth_validate_addr,
};

static void hwsim_mon_setup(struct net_device *dev)
{
	dev->netdev_ops = &hwsim_netdev_ops;
	dev->needs_free_netdev = true;
	ether_setup(dev);
	dev->priv_flags |= IFF_NO_QUEUE;
	dev->type = ARPHRD_IEEE80211_RADIOTAP;
	eth_zero_addr(dev->dev_addr);
	memcpy(dev->dev_addr, rdkfmac_mac_addr, ETH_ALEN);
}

static int __init rdkfmac_init_module(void)
{
	int err;

	spin_lock_init(&radio_lock);

	err = register_pernet_device(&rdkfmac_net_ops);
	if (err)
	    return -EINVAL;

	err = platform_driver_register(&mac80211_rdkfmac_driver);
	if (err)
		goto out_unregister_pernet;

	err = rdkfmac_init_netlink();
	if (err)
		goto out_unregister_driver;

	rdkfmac_class = class_create(THIS_MODULE, "mac80211_rdkfmac");
	if (IS_ERR(rdkfmac_class)) {
		err = PTR_ERR(rdkfmac_class);
		goto out_exit_netlink;
	}

	err = mac80211_rdkfmac_new_radio();
	if (err < 0)
	    goto out_free_radios;

	init_rdkfmac_cdev();

	return 0;

out_free_radios:
	mac80211_rdkfmac_free();
out_exit_netlink:
	rdkfmac_exit_netlink();
out_unregister_driver:
	platform_driver_unregister(&mac80211_rdkfmac_driver);
out_unregister_pernet:
	unregister_pernet_device(&rdkfmac_net_ops);
	return err;
}

static void __exit rdkfmac_cleanup_module(void)
{
    printk("%s:%d Unloading module: %s success\n", __func__, __LINE__, NETDEV_DRV_NAME);

    rdkfmac_exit_netlink();
    mac80211_rdkfmac_free();
    platform_driver_unregister(&mac80211_rdkfmac_driver);
    unregister_pernet_device(&rdkfmac_net_ops);
}

module_init(rdkfmac_init_module);
module_exit(rdkfmac_cleanup_module);
MODULE_LICENSE("GPL");
MODULE_ALIAS_RTNL_LINK(NETDEV_DRV_NAME);
