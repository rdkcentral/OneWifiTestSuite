#ifndef RDKFMAC_H
#define RDKFMAC_H

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/semaphore.h>
#include <linux/ip.h>
#include <linux/skbuff.h>
#include <linux/if_arp.h>
#include <linux/etherdevice.h>
#include <net/sock.h>
#include <net/lib80211.h>
#include <net/cfg80211.h>
#include <linux/vmalloc.h>
#include <linux/firmware.h>
#include <linux/ctype.h>
#include <linux/workqueue.h>
#include <linux/slab.h>
#include <linux/platform_device.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/ethtool.h>
#include <linux/init.h>
#include <linux/moduleparam.h>
#include <linux/rtnetlink.h>
#include <linux/net_tstamp.h>
#include <linux/wait.h>
#include <linux/poll.h>
#include <linux/list.h>
#include <net/rtnetlink.h>
#include <linux/u64_stats_sync.h>
#include <linux/cdev.h>
#include <net/mac80211.h>
#include "wlan_emu_80211_analyzer.h"

#define NETDEV_DRV_NAME "rdkfmac"

#define RDKFMAC_MAJOR       42
#define BUF_LEN 256
#define RDKFMAC_DEVICE_NAME "rdkfmac_dev"
#define RDKFMAC_DEVICE_DRIVER_NAME  "rdkfmac_device_driver"
#define RDKFMAC_CLASS_NAME "rdkfmac_class"
#define RDKFMAC_WDOG_TIMEOUT	5
#define RDKFMAC_PRIMARY_VIF_IDX	0
#define RDKFMAC_MAX_MAC        	3
#define RDKFMAC_MAX_INTF		8       
#define RDKFMAC_MAX_VSIE_LEN       255

enum rdkfmac_hw_capab {
    RDKFMAC_HW_CAPAB_REG_UPDATE = 0,
    RDKFMAC_HW_CAPAB_STA_INACT_TIMEOUT,
    RDKFMAC_HW_CAPAB_DFS_OFFLOAD,
    RDKFMAC_HW_CAPAB_SCAN_RANDOM_MAC_ADDR,
    RDKFMAC_HW_CAPAB_PWR_MGMT,
    RDKFMAC_HW_CAPAB_OBSS_SCAN,
    RDKFMAC_HW_CAPAB_SCAN_DWELL,
    RDKFMAC_HW_CAPAB_SAE,
    RDKFMAC_HW_CAPAB_HW_BRIDGE,
    RDKFMAC_HW_CAPAB_NUM
};

typedef struct rdkfmac_hw_info {
    u32 ql_proto_ver;
    u8 num_mac;
    u8 mac_bitmap;
    u32 fw_ver;
    u8 total_tx_chain;
    u8 total_rx_chain;
    char fw_version[ETHTOOL_FWVERS_LEN];
    u32 hw_version;
    u8 hw_capab[RDKFMAC_HW_CAPAB_NUM / BITS_PER_BYTE + 1];
} rdkfmac_hw_info_t;

typedef struct {
	wlan_emu_spec_data_t *spec;
	struct list_head	list_entry;
} wlan_emu_spec_data_entry_t;

typedef struct rdkfmac_device_data {
    struct cdev cdev;
    struct class*  rdkfmac_class;
    struct device* rdkfmac_dev;
	struct list_head list_head;
	struct list_head *list_tail;
} rdkfmac_device_data_t;

struct rdkfmac_wmac;
struct rdkfmac_bus;

typedef struct rdkfmac_vif {
	struct wireless_dev wdev;
	u8 bssid[ETH_ALEN];
	u8 mac_addr[ETH_ALEN];
	u8 vifid;
	struct net_device *netdev;
	struct rdkfmac_wmac *mac;
	struct work_struct reset_work;
    struct work_struct high_pri_tx_work;
    struct sk_buff_head high_pri_tx_queue;
    unsigned long cons_tx_timeout_cnt;
    int generation;
} rdkfmac_vif_t;

typedef struct {
    u8 bands_cap;
    u8 num_tx_chain;
    u8 num_rx_chain;
    u16 max_ap_assoc_sta;
    u32 frag_thr;
    u32 rts_thr;
    u8 lretry_limit;
    u8 sretry_limit;
    u8 coverage_class;
    u8 radar_detect_widths;
    u8 max_scan_ssids;
    u16 max_acl_mac_addrs;
    struct ieee80211_ht_cap ht_cap_mod_mask;
    struct ieee80211_vht_cap vht_cap_mod_mask;
    struct ieee80211_iface_combination *if_comb;
    size_t n_if_comb;
    u8 *extended_capabilities;
    u8 *extended_capabilities_mask;
    u8 extended_capabilities_len;
    struct wiphy_wowlan_support *wowlan;
} rdkfmac_mac_info_t;

typedef struct rdkfmac_wmac {
	u8 macid;
	u8 wiphy_registered;
	u8 macaddr[ETH_ALEN];
	struct rdkfmac_bus *bus;
	rdkfmac_mac_info_t macinfo;
	struct rdkfmac_vif iflist[RDKFMAC_MAX_INTF];
    struct cfg80211_scan_request *scan_req;
    struct mutex mac_lock;  /* lock during wmac speicific ops */
    struct delayed_work scan_timeout;
    struct ieee80211_regdomain *rd;
    struct platform_device *pdev;
} rdkfmac_wmac_t;

typedef enum {
    RDKFMAC_FW_STATE_DETACHED,
    RDKFMAC_FW_STATE_BOOT_DONE,
    RDKFMAC_FW_STATE_ACTIVE,
    RDKFMAC_FW_STATE_RUNNING,
    RDKFMAC_FW_STATE_DEAD,
} rdkfmac_fw_state_t;

struct rdkfmac_frame_meta_info {
    u8 magic_s;
    u8 ifidx;
    u8 macid;
    u8 magic_e;
} __packed;

struct rdkfmac_bus;

typedef struct rdkfmac_bus_ops {
    /* mgmt methods */
    int (*preinit)(struct rdkfmac_bus *);
    void (*stop)(struct rdkfmac_bus *);

    /* control path methods */
    int (*control_tx)(struct rdkfmac_bus *, struct sk_buff *);

    /* data xfer methods */
    int (*data_tx)(struct rdkfmac_bus *bus, struct sk_buff *skb,
               unsigned int macid, unsigned int vifid);
    void (*data_tx_timeout)(struct rdkfmac_bus *, struct net_device *);
    void (*data_tx_use_meta_set)(struct rdkfmac_bus *bus, bool use_meta);
    void (*data_rx_start)(struct rdkfmac_bus *);
    void (*data_rx_stop)(struct rdkfmac_bus *);
} rdkfmac_bus_ops_t;

typedef struct rdkfmac_cmd_ctl_node {
    struct completion cmd_resp_completion;
    struct sk_buff *resp_skb;
    u16 seq_num;
    bool waiting_for_resp;
    spinlock_t resp_lock; /* lock for resp_skb & waiting_for_resp changes */
} rdkfmac_cmd_ctl_node_t;

typedef struct rdkfmac_qlink_transport {
    rdkfmac_cmd_ctl_node_t curr_cmd;
    struct sk_buff_head event_queue;
    size_t event_queue_max_len;
} rdkfmac_qlink_transport_t;

typedef struct rdkfmac_bus {
    struct device *dev;
    rdkfmac_fw_state_t fw_state;
    u32 chip;
    u32 chiprev;
    struct rdkfmac_bus_ops *bus_ops;
    rdkfmac_wmac_t *mac[RDKFMAC_MAX_MAC];
    rdkfmac_cmd_ctl_node_t trans;
    struct rdkfmac_hw_info hw_info;
    struct napi_struct mux_napi;
    struct net_device mux_dev;
    struct workqueue_struct *workqueue;
    struct workqueue_struct *hprio_workqueue;
    struct work_struct fw_work;
    struct work_struct event_work;
    struct mutex bus_lock; /* lock during command/event processing */
    struct dentry *dbg_dir;
    struct notifier_block netdev_nb;
    u8 hw_id[ETH_ALEN];
    /* bus private data */
    char bus_priv[] __aligned(sizeof(void *));
} rdkfmac_bus_t;

#define CHAN2G(_freq)  { \
    .band = NL80211_BAND_2GHZ, \
    .center_freq = (_freq), \
    .hw_value = (_freq), \
    .max_power = 20, \
}

#define CHAN5G(_freq) { \
    .band = NL80211_BAND_5GHZ, \
    .center_freq = (_freq), \
    .hw_value = (_freq), \
    .max_power = 20, \
}

static const struct ieee80211_channel rdkfmac_channels_2ghz[] = {
    CHAN2G(2412), /* Channel 1 */
    CHAN2G(2417), /* Channel 2 */
    CHAN2G(2422), /* Channel 3 */
    CHAN2G(2427), /* Channel 4 */
    CHAN2G(2432), /* Channel 5 */
    CHAN2G(2437), /* Channel 6 */
    CHAN2G(2442), /* Channel 7 */
    CHAN2G(2447), /* Channel 8 */
    CHAN2G(2452), /* Channel 9 */
    CHAN2G(2457), /* Channel 10 */
    CHAN2G(2462), /* Channel 11 */
    CHAN2G(2467), /* Channel 12 */
    CHAN2G(2472), /* Channel 13 */
    CHAN2G(2484), /* Channel 14 */
};

static const struct ieee80211_channel rdkfmac_channels_5ghz[] = {
    CHAN5G(5180), /* Channel 36 */
    CHAN5G(5200), /* Channel 40 */
    CHAN5G(5220), /* Channel 44 */
    CHAN5G(5240), /* Channel 48 */
            
    CHAN5G(5260), /* Channel 52 */
    CHAN5G(5280), /* Channel 56 */
    CHAN5G(5300), /* Channel 60 */
    CHAN5G(5320), /* Channel 64 */
                
    CHAN5G(5500), /* Channel 100 */
    CHAN5G(5520), /* Channel 104 */
    CHAN5G(5540), /* Channel 108 */
    CHAN5G(5560), /* Channel 112 */
    CHAN5G(5580), /* Channel 116 */
    CHAN5G(5600), /* Channel 120 */
    CHAN5G(5620), /* Channel 124 */
    CHAN5G(5640), /* Channel 128 */
    CHAN5G(5660), /* Channel 132 */
    CHAN5G(5680), /* Channel 136 */
    CHAN5G(5700), /* Channel 140 */

    CHAN5G(5745), /* Channel 149 */
    CHAN5G(5765), /* Channel 153 */
    CHAN5G(5785), /* Channel 157 */
    CHAN5G(5805), /* Channel 161 */
    CHAN5G(5825), /* Channel 165 */
    CHAN5G(5845), /* Channel 169 */
};

static const struct ieee80211_rate rdkfmac_rates[] = {
    { .bitrate = 10 },
    { .bitrate = 20, .flags = IEEE80211_RATE_SHORT_PREAMBLE },
    { .bitrate = 55, .flags = IEEE80211_RATE_SHORT_PREAMBLE },
    { .bitrate = 110, .flags = IEEE80211_RATE_SHORT_PREAMBLE },
    { .bitrate = 60 },
    { .bitrate = 90 },
    { .bitrate = 120 },
    { .bitrate = 180 },
    { .bitrate = 240 },
    { .bitrate = 360 },
    { .bitrate = 480 },
    { .bitrate = 540 }
};

static const u32 rdkfmac_ciphers[] = {
    WLAN_CIPHER_SUITE_TKIP,
    WLAN_CIPHER_SUITE_CCMP,
    WLAN_CIPHER_SUITE_CCMP_256,
    WLAN_CIPHER_SUITE_GCMP,
    WLAN_CIPHER_SUITE_GCMP_256,
    WLAN_CIPHER_SUITE_AES_CMAC,
};

struct rdkfmac_sta_priv {
    u32 magic;
};

struct rdkfmac_vif_priv { 
    u32 magic;
    u8 bssid[ETH_ALEN];
    bool assoc;
    bool bcn_en;
    u16 aid;
};  

struct mac80211_rdkfmac_data {
    struct list_head list;
    struct rhash_head rht;
    struct ieee80211_hw *hw;
    struct device *dev;
    struct ieee80211_supported_band bands[NUM_NL80211_BANDS];
    struct ieee80211_channel channels_2ghz[ARRAY_SIZE(rdkfmac_channels_2ghz)];
    struct ieee80211_channel channels_5ghz[ARRAY_SIZE(rdkfmac_channels_5ghz)];
    struct ieee80211_rate rates[ARRAY_SIZE(rdkfmac_rates)];
    struct ieee80211_iface_combination if_combination;
    struct ieee80211_iface_limit if_limits[3];
    int n_if_limits;

    u32 ciphers[ARRAY_SIZE(rdkfmac_ciphers)];

    struct mac_address addresses[2];
    int channels, idx;
    bool use_chanctx;
    bool destroy_on_close;
    u32 portid;
    char alpha2[2];
    const struct ieee80211_regdomain *regd;

    struct ieee80211_channel *tmp_chan;
    struct ieee80211_channel *roc_chan;
    u32 roc_duration;
    struct delayed_work roc_start;
    struct delayed_work roc_done;
    struct delayed_work hw_scan;
    struct cfg80211_scan_request *hw_scan_request;
    struct ieee80211_vif *hw_scan_vif;
    int scan_chan_idx;
    u8 scan_addr[ETH_ALEN];
    struct {
        struct ieee80211_channel *channel;
        unsigned long next_start, start, end;
    } survey_data[ARRAY_SIZE(rdkfmac_channels_2ghz) + ARRAY_SIZE(rdkfmac_channels_5ghz)];

    struct ieee80211_channel *channel;
    u64 beacon_int;
    unsigned int rx_filter;
    bool started, idle, scanning;
    struct mutex mutex;
    struct hrtimer beacon_timer;
    enum ps_mode {
        PS_DISABLED, PS_ENABLED, PS_AUTO_POLL, PS_MANUAL_POLL
    } ps;
    bool ps_poll_pending;
    struct dentry *debugfs;

    uintptr_t pending_cookie;
    struct sk_buff_head pending;
    u64 group;

    int netgroup;
    u32 wmediumd;

    s64 tsf_offset;
    s64 bcn_delta;
    u64 abs_bcn_ts;

    u64 tx_pkts;
    u64 rx_pkts;
    u64 tx_bytes;
    u64 rx_bytes;
    u64 tx_dropped;
    u64 tx_failed;
};


int init_rdkfmac_cdev(void);
void cleanup_rdkfmac_cdev(void);
void rdkfmac_bus_pseudo_init(rdkfmac_bus_t *bus);
rdkfmac_bus_t *rdkfmac_get_bus(void);
struct wiphy *rdkfmac_wiphy_allocate(rdkfmac_bus_t *bus, struct platform_device *pdev);
struct ieee80211_ops *rdkfmac_get_ieee80211_ops(void);
struct rdkfmac_device_data *get_char_device_data(void);
void push_to_char_device(wlan_emu_spec_data_t *data);

static inline rdkfmac_vif_t *rdkfmac_netdev_get_priv(struct net_device *dev)
{   
    return *((void **)netdev_priv(dev));
}

static inline bool rdkfmac_dfs_offload_get(void)
{
	return false;
}

static inline bool rdkfmac_hwcap_is_set(rdkfmac_hw_info_t *hw_info, unsigned int bit)
{
	return false;
}  

#endif // RDKFMAC_H
